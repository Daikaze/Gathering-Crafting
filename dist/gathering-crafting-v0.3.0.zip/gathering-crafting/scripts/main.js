/** Gathering & Crafting v0.2.0 — Foundry V14 / dnd5e 5.3.3. */
import { CATALOG } from './catalog.js';
import { makeMaterialData, makeCraftData, outputKind } from './items.js';
const ID='gathering-crafting';
const VERSION='0.3.0';
const clone=value=>foundry.utils.deepClone(value);
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=(v,f=0,min=0,max=9999)=>Number.isFinite(Number(v))?Math.min(max,Math.max(min,Math.trunc(Number(v)))):f;
const icon=v=>`<i class="fa-solid ${/^fa-[a-z0-9-]+$/.test(String(v))?v:'fa-cube'}" aria-hidden="true"></i>`;
const hue=v=>/^#[0-9a-fA-F]{6}$/.test(String(v))?v:'#a7b9cb';
const notify=(message,error=false)=>ui.notifications[error?'error':'info'](message);
const database=()=>game.settings.get(ID,'database');
const material=(db,id)=>db.materials.find(m=>m.id===id);
const skillLabels={ath:'Athletics',sur:'Survival',prc:'Perception',inv:'Investigation',nat:'Nature',slt:'Sleight of Hand'};
const skills=Object.entries(skillLabels);
const categories=[['all','All Recipes','fa-layer-group'],['metallurgy','Metallurgy','fa-hammer'],['alchemy','Alchemy','fa-flask']];
const materialGroups=[['all','All','fa-layer-group'],['metallurgy','Ores & Metals','fa-gem'],['alchemy','Potion Ingredients','fa-leaf']];
const validDb=db=>!!(db&&Array.isArray(db.materials)&&Array.isArray(db.nodes)&&Array.isArray(db.recipes));
const resourceItem=(item,id)=>item.getFlag?.(ID,'resourceId')===id||(CATALOG.materials.some(m=>m.id===id&&m.group==='Refined Metal')&&item.getFlag?.(ID,'recipeId')===id);
const itemStacks=(actor,id)=>actor.items.filter(i=>resourceItem(i,id));
const quantity=(item)=>num(item.system?.quantity,1);
const count=(actor,id)=>actor?itemStacks(actor,id).reduce((n,i)=>n+quantity(i),0):0;
const attempts=actor=>num(actor?.getFlag(ID,'attempts'),0);
const skillBonus=(actor,id)=>{
  const sk=actor.system?.skills?.[id]||{};
  if(sk.total!=null&&Number.isFinite(Number(sk.total)))return Number(sk.total);
  const key=sk.ability||(id==='ath'?'str':id==='slt'?'dex':id==='nat'||id==='inv'?'int':'wis');
  const mod=Number(sk.mod??actor.system?.abilities?.[key]?.mod??0);
  return Math.trunc(mod+Number(actor.system?.attributes?.prof??2)*Number(sk.value??0));
};
async function grantMaterial(actor,mat,qty){
  const existing=itemStacks(actor,mat.id)[0];
  if(existing)await existing.update({'system.quantity':quantity(existing)+qty});
  else await actor.createEmbeddedDocuments('Item',[makeMaterialData(mat,qty)]);
}
async function consume(actor,ingredients){
  const merged=new Map();
  for(const ing of ingredients)merged.set(ing.id,(merged.get(ing.id)||0)+num(ing.qty,0));
  for(const [id,required] of merged)if(count(actor,id)<required)throw new Error(`Not enough ${id}.`);
  const originals=[...merged.keys()].flatMap(id=>itemStacks(actor,id)).map(i=>({id:i.id,quantity:quantity(i),data:i.toObject()}));
  const updates=[],removals=[];
  for(const [id,required] of merged){let left=required;for(const stack of itemStacks(actor,id)){
    if(left<=0)break;
    const used=Math.min(left,quantity(stack));left-=used;
    if(quantity(stack)-used>0)updates.push({_id:stack.id,'system.quantity':quantity(stack)-used});else removals.push(stack.id);
  }}
  try{if(updates.length)await actor.updateEmbeddedDocuments('Item',updates);if(removals.length)await actor.deleteEmbeddedDocuments('Item',removals);}
  catch(error){
    try{for(const old of originals){const now=actor.items.get?.(old.id)||actor.items.find(i=>i.id===old.id);
      if(now)await now.update({'system.quantity':old.quantity});
      else{const data=clone(old.data);delete data._id;await actor.createEmbeddedDocuments('Item',[data]);}
    }}catch(rollbackError){console.error(`${ID} | Inventory rollback incomplete`,rollbackError);notify('Inventory rollback failed: ask your GM to restore materials.',true);}
    throw error;
  }
}
async function refund(actor,ingredients,db){for(const entry of ingredients){const mat=material(db,entry.id);if(mat)await grantMaterial(actor,mat,num(entry.qty));}}
async function grantProduct(actor,recipe,qty){
  let data=makeCraftData(recipe,qty);
  if(recipe.outputItemUuid){
    const source=await fromUuid(recipe.outputItemUuid);
    if(!source||source.documentName!=='Item')throw new Error('The linked output Item no longer exists. Ask your GM to relink it.');
    data=source.toObject();delete data._id;data.system||={};data.system.quantity=qty;
    data.flags||={};data.flags[ID]={...(data.flags[ID]||{}),recipeId:recipe.id,effect:recipe.effect||'',...(database().materials.some(m=>m.id===recipe.id)?{resourceId:recipe.id}:{})};
  }
  const existing=['loot','consumable'].includes(data.type)?actor.items.find(i=>(i.getFlag(ID,'recipeId')===recipe.id||(data.flags[ID].resourceId&&i.getFlag(ID,'resourceId')===data.flags[ID].resourceId))&&i.name===data.name&&i.type===data.type):null;
  if(existing)await existing.update({'system.quantity':quantity(existing)+qty});
  else await actor.createEmbeddedDocuments('Item',[data]);
}
function ownedActors(){return(game.actors?.contents||[]).filter(a=>['character','npc'].includes(a.type)&&(game.user.isGM||a.isOwner))
 .sort((a,b)=>Number(b.type==='character')-Number(a.type==='character')||a.name.localeCompare(b.name));}
function currentActor(id){const list=ownedActors();if(id)return list.find(a=>a.id===id)||null;
  const controlled=canvas?.tokens?.controlled?.[0]?.actor;
  return list.find(a=>a.id===controlled?.id)||list.find(a=>a.id===game.user.character?.id)||list[0]||null;
}
function requirements(actor,recipe,db,bonus=false){return recipe.ingredients.map((ing,i)=>({id:ing.id,qty:num(ing.qty,1)+(bonus&&i===0?1:0),mat:material(db,ing.id),have:count(actor,ing.id)}));}
async function announce(actor,html){try{await ChatMessage.create({speaker:ChatMessage.getSpeaker({actor}),content:`<section class="gc-chat"><h3>Gathering & Crafting</h3>${html}</section>`});}catch(e){console.warn(`${ID} | Chat notice failed`,e);}}
const nodeTokens=(id)=>canvas?.tokens?.placeables?.filter(t=>t.document?.getFlag?.(ID,'nodeId')===id&&t.visible!==false)||[];
function nearestNodeToken(actor,id){const token=canvas?.tokens?.placeables?.find(t=>t.actor?.id===actor.id);
  if(!token)return null;
  return nodeTokens(id).map(t=>({token:t,feet:Math.hypot(t.center.x-token.center.x,t.center.y-token.center.y)/(canvas?.grid?.size||100)*Number(canvas?.scene?.grid?.distance||5)}))
    .sort((a,b)=>a.feet-b.feet)[0]||null;
}
function mergeCatalog(old){
  const db=clone(CATALOG);
  if(!validDb(old))return db;
  db.settings={...db.settings,...(old.settings||{})};
  const builtInMaterials=new Set(['iron-ore','copper-ore','oak-wood','herbs','crystal','leather','monster-bone','wild-flower']);
  const builtInNodes=new Set(['old-mine','copper-vein','green-grove','old-oaks','bone-field']);
  const builtInRecipes=new Set(['iron-ingot','copper-ring','healing-salve','oak-handle','leather-wrap','arcane-focus']);
  // Keep custom additions that fit the two professions; archive old defaults in backup settings.
  const owned=new Set(db.materials.map(m=>m.id));
  const needed=new Set();
  for(const x of old.recipes)if(!builtInRecipes.has(x.id)&&['smithing','alchemy','metallurgy'].includes(x.category))for(const i of x.ingredients||[])needed.add(i.id);
  for(const m of old.materials)if(!owned.has(m.id)&&!builtInMaterials.has(m.id)&&needed.has(m.id)){db.materials.push(m);owned.add(m.id);}
  const recipeIds=new Set(db.recipes.map(r=>r.id));
  for(const r of old.recipes)if(!recipeIds.has(r.id)&&!builtInRecipes.has(r.id)&&['smithing','metallurgy','alchemy'].includes(r.category)&&(r.ingredients||[]).every(i=>owned.has(i.id))){
    db.recipes.push({...r,category:r.category==='smithing'?'metallurgy':r.category,subcategory:r.subcategory||'Custom',tier:r.tier||1});recipeIds.add(r.id);
  }
  const nodeIds=new Set(db.nodes.map(n=>n.id));
  for(const n of old.nodes)if(!nodeIds.has(n.id)&&!builtInNodes.has(n.id)&&owned.has(n.materialId))db.nodes.push(n);
  return db;
}
let syncing=false;
async function ensurePack(name,label){
  let pack=game.packs.get(`world.${name}`);
  if(!pack)pack=await foundry.documents.collections.CompendiumCollection.createCompendium({name,label,type:'Item',system:'dnd5e',package:'world'});
  return pack;
}
async function syncCompendiums(){
  if(!game.user.isGM)throw new Error('Only a GM can create the compendiums.');
  if(syncing)return;
  syncing=true;
  try{
    const db=database();
    const sources=[
      ['gc-ores-metals','Gathering & Crafting | Ores & Metals',db.materials.filter(m=>m.group!=='Alchemical Ingredient').map(m=>makeMaterialData(m)),'resourceId'],
      ['gc-ingredients','Gathering & Crafting | Alchemy Ingredients',db.materials.filter(m=>m.group==='Alchemical Ingredient').map(m=>makeMaterialData(m)),'resourceId'],
      ['gc-ready-items','Gathering & Crafting | Ready-to-use Items',db.recipes.map(r=>makeCraftData(r)),'recipeId']];
    let added=0;
    for(const [name,label,all,key] of sources){
      const pack=await ensurePack(name,label);
      const previouslyLocked=!!pack.locked;
      if(previouslyLocked)await pack.configure({locked:false});
      try{
        // Do not overwrite GM modifications. Missing entries only, identified by permanent catalog flags.
        const existing=await pack.getDocuments();
        const ids=new Set(existing.map(it=>it.getFlag(ID,key)).filter(Boolean));
        const missing=all.filter(it=>!ids.has(it.flags[ID][key]));
        for(let i=0;i<missing.length;i+=25){await Item.implementation.createDocuments(missing.slice(i,i+25),{pack:pack.collection});added+=Math.min(25,missing.length-i);}
      }finally{if(previouslyLocked)await pack.configure({locked:true});}
    }
    await game.settings.set(ID,'compendiumBootstrapped030',true);
    notify(added?`Compendiums ready: ${added} new Items added.`:'Compendiums are already up to date.');
  }finally{syncing=false;}
}
class GatheringCrafting extends foundry.applications.api.ApplicationV2{
  static DEFAULT_OPTIONS={id:'gc-main-window',classes:['gathering-crafting'],window:{title:'Gathering & Crafting',icon:'fa-solid fa-hammer',resizable:true},position:{width:970,height:740}};
  constructor(opts={}){super(opts);this.actorId=currentActor()?.id||null;this.tab='gather';this.gatherMode='careful';this.craftMode='steady';this.category='all';this.group='all';this.search='';this.page=1;this.showZero=false;this.readyOnly=false;this.editor={kind:'material',id:null};this.busy=false;this.searchTimer=null;}
  get actor(){return currentActor(this.actorId);}
  async _renderHTML(){const root=document.createElement('div');root.className='gc-root';root.innerHTML=this.template();return root;}
  _replaceHTML(result,content){content.replaceChildren(result);}
  async _onRender(context,options){await super._onRender(context,options);const root=this.element.querySelector('.gc-root');if(!root)return;
    root.addEventListener('click',e=>this.click(e));root.addEventListener('change',e=>this.change(e));root.addEventListener('input',e=>this.input(e));root.addEventListener('submit',e=>this.submit(e));}
  refresh(){return this.render({force:true});}
  heading(ic,title,description){return `<header class="gc-section-head"><div><h2>${icon(ic)} ${esc(title)}</h2><p>${esc(description)}</p></div></header>`;}
  tabButton(id,ic,title){return `<button type="button" class="gc-nav ${this.tab===id?'is-active':''}" data-action="tab" data-id="${id}">${icon(ic)} <span>${title}</span></button>`;}
  filterBar(choices,selected,action){return `<div class="gc-category">${choices.map(([id,label,ic])=>`<button type="button" class="${selected===id?'is-on':''}" data-action="${action}" data-id="${id}">${icon(ic)} ${esc(label)}</button>`).join('')}</div>`;}
  searchBar(){return `<label class="gc-search">${icon('fa-magnifying-glass')}<input type="search" data-search="1" placeholder="Search..." value="${esc(this.search)}"></label>`;}
  renderCards(all,renderer){const pageSize=9;const visible=all.slice(0,this.page*pageSize);
    return `<div class="gc-grid">${visible.map(renderer).join('')||'<div class="gc-empty">Nothing matches the current filters.</div>'}</div>`+
     (visible.length<all.length?`<button class="gc-secondary gc-more" type="button" data-action="more">${icon('fa-chevron-down')} Show more (${all.length-visible.length} remaining)</button>`:'');
  }
  template(){const db=database();if(!validDb(db))return '<div class="gc-empty">The crafting catalogue could not be loaded.</div>';
    const actor=this.actor,gm=game.user.isGM,cap=num(db.settings.dailyLimit,6,1,100),left=actor?Math.max(0,cap-attempts(actor)):0;
    const choices=ownedActors().map(a=>`<option value="${esc(a.id)}" ${actor?.id===a.id?'selected':''}>${esc(a.name)} (${a.type==='character'?'PC':'NPC'})</option>`).join('');
    return `<div class="gc-top"><div class="gc-brand"><span class="gc-brand-logo">${icon('fa-hammer')}</span><div><span class="gc-subtitle">THE AVERIS WORKSHOP · v${VERSION}</span><div class="gc-brand-title">Gathering <span>&</span> Crafting</div></div></div>
      <div class="gc-top-right">${gm?`<button class="gc-gm-shortcut" type="button" data-action="tab" data-id="gm" aria-label="GM Workshop" title="GM Workshop">${icon('fa-gear')}</button>`:''}<label class="gc-selectwrap">${icon('fa-user')}<select name="actor" aria-label="Character">${choices}</select></label><div class="gc-energy" title="Remaining gathering actions">${icon('fa-bolt')} <b>${left}</b><small>/ ${cap} gathers</small></div></div></div>
      <nav class="gc-tabs">${this.tabButton('gather','fa-mountain','Gather')}${this.tabButton('craft','fa-hammer','Craft')}${this.tabButton('backpack','fa-box-open','Inventory')}</nav>
      <div class="gc-content">${!actor&&this.tab!=='gm'?'<div class="gc-empty">Select a character with Owner permission to get started.</div>':this.tab==='gather'?this.gatherTab(db,actor):this.tab==='craft'?this.craftTab(db,actor):this.tab==='backpack'?this.inventoryTab(db,actor):gm?this.gmTab(db):''}</div>
      <footer class="gc-footer"><span>${icon('fa-box')} All materials are real D&D 5e Items that can be moved between inventories and compendiums.</span><span>v${VERSION} · Foundry V14 · dnd5e 5.3.3</span></footer>`;
  }
  gatherTab(db,actor){const sceneOnly=!!db.settings.sceneOnly;
    const found=db.nodes.filter(n=>n.active&&(!sceneOnly||nodeTokens(n.id).length)&& (this.group==='all'||(n.group||'metallurgy')===this.group) &&(!this.search||`${n.name} ${n.description}`.toLowerCase().includes(this.search.toLowerCase())));
    return this.heading('fa-mountain','Gather Resources','Choose a resource. One click to gather, with an optional risk for more.')+
      `<div class="gc-toolbar"><div class="gc-mode"><button type="button" data-action="gmode" data-mode="careful" class="${this.gatherMode==='careful'?'is-on':''}">${icon('fa-shield-heart')} Careful <small>DC −2 · standard yield</small></button>
      <button type="button" data-action="gmode" data-mode="bold" class="${this.gatherMode==='bold'?'is-on':''}">${icon('fa-bolt')} Risky <small>DC +3 · double yield</small></button></div>${this.searchBar()}</div>`+
      this.filterBar(materialGroups,this.group,'group')+
      `<div class="gc-notice">${icon('fa-circle-info')} ${sceneOnly?'Scene gathering: only visible bound map tokens can be harvested (within 15 ft).':'Free gathering: available nodes can be used anywhere. GM can switch to Scene-only in GM Studio.'} ${Math.max(0,num(db.settings.dailyLimit,6)-attempts(actor))} attempts left.</div>`+
      this.renderCards(found,n=>this.nodeCard(db,n,actor));
  }
  nodeCard(db,n,actor){const mat=material(db,n.materialId),rare=material(db,n.bonusId),left=num(db.settings.dailyLimit,6)-attempts(actor),dc=num(n.dc,12)+(this.gatherMode==='bold'?3:-2);
    return `<article class="gc-tile gc-node"><div class="gc-tile-banner"><span class="gc-hero-icon"><img class="gc-art-img" src="${esc(mat?.img||'icons/svg/item-bag.svg')}" alt=""></span><span class="gc-dc">Tier ${mat?.tier||1} · ${esc(skillLabels[n.skill]||n.skill)} DC ${dc}</span></div><div class="gc-tile-body"><h3>${esc(n.name)}</h3><p>${esc(n.description)}</p><div class="gc-loot"><span class="gc-mat-icon" style="--gc-mat:${hue(mat?.color)}"><img src="${esc(mat?.img||'icons/svg/item-bag.svg')}" alt=""></span><div><b>${esc(mat?.name||'Missing item')}</b><small>Yield: ${num(n.minYield,1)}–${num(n.maxYield,2)}${this.gatherMode==='bold'?' ×2':''}</small></div>${rare?`<span class="gc-rare">${icon('fa-gem')} ${num(n.bonusChance,0,0,100)}%</span>`:''}</div><button class="gc-primary" type="button" data-action="gather" data-id="${esc(n.id)}" ${left<=0||!mat||this.busy?'disabled':''}>${icon('fa-hand-sparkles')} Gather</button></div></article>`;
  }
  craftTab(db,actor){
    const all=db.recipes.filter(r=>(this.category==='all'||r.category===this.category)&&(!this.search||`${r.name} ${r.description} ${r.subcategory}`.toLowerCase().includes(this.search.toLowerCase())));
    const ready=r=>r.ingredients?.length&&requirements(actor,r,db,this.craftMode==='inspired').every(i=>i.mat&&i.have>=i.qty);
    const found=all.filter(r=>!this.readyOnly||ready(r)).sort((a,b)=>Number(!!ready(b))-Number(!!ready(a))||a.tier-b.tier||a.name.localeCompare(b.name));
    const possible=all.filter(ready).length;
    return this.heading('fa-book-open','Your Recipe Book',`${possible} ready to craft · ${all.length} recipes available. Select a recipe and press Craft.`)+
    `<div class="gc-toolbar gc-compact-toolbar"><div class="gc-mode"><button class="${this.craftMode==='steady'?'is-on':''}" data-action="cmode" data-mode="steady">${icon('fa-check')} Reliable <small>Always succeeds</small></button><button class="${this.craftMode==='inspired'?'is-on':''}" data-action="cmode" data-mode="inspired">${icon('fa-star')} Inspired <small>Extra ingredient for bonus</small></button></div>${this.searchBar()}</div>`+
    `<div class="gc-browser-row">${this.filterBar(categories,this.category,'category')}<button class="gc-ready-toggle ${this.readyOnly?'is-on':''}" type="button" data-action="readyOnly">${icon('fa-check-circle')} Craftable only (${possible})</button></div>`+
    (this.readyOnly&&!found.length?`<div class="gc-empty gc-easy-empty">${icon('fa-box-open')}<strong>No recipes ready yet</strong><span>Gather resources or open the complete recipe book to see what you need.</span><button type="button" class="gc-secondary" data-action="readyOnly">Show all recipes</button></div>`:this.renderCards(found,r=>this.recipeCard(db,r,actor)));
  }
  recipeCard(db,r,actor){const req=requirements(actor,r,db,this.craftMode==='inspired'),can=req.length&&req.every(i=>i.mat&&i.have>=i.qty);
    const kind=outputKind(r),kindText={weapon:'Weapon',equipment:'Armor',consumable:'Potion',loot:r.subcategory==='Smelting'?'Metal':'Crafting Good'}[kind]||'Item';
    const max=can?Math.max(1,Math.min(10,...req.map(i=>Math.floor(i.have/i.qty)))):0;
    return `<article class="gc-tile gc-recipe ${can?'gc-ready':''}"><div class="gc-tile-banner gc-craft-art"><span class="gc-hero-icon"><img class="gc-art-img" src="${esc(r.img||'icons/svg/item-bag.svg')}" alt=""></span><span class="gc-dc">${esc(kindText)} · Tier ${num(r.tier,1)}</span>${can?'<span class="gc-ready-tag">Ready</span>':''}</div><div class="gc-tile-body"><h3>${esc(r.name)}</h3><p>${esc(r.description)}</p><div class="gc-ingredients">${req.map(i=>`<div class="gc-ingredient ${i.have>=i.qty?'gc-have':'gc-miss'}"><span class="gc-mat-icon" style="--gc-mat:${hue(i.mat?.color)}"><img src="${esc(i.mat?.img||'icons/svg/item-bag.svg')}" alt=""></span><span>${esc(i.mat?.name||'Missing material')}</span><b>${i.have}/${i.qty}</b></div>`).join('')}</div><div class="gc-craft-actions"><button class="gc-primary" type="button" data-action="craft" data-id="${esc(r.id)}" ${!can||this.busy?'disabled':''}>${icon(can?'fa-hammer':'fa-lock')} ${can?'Craft':'Missing materials'}</button>${max>1&&this.craftMode==='steady'?`<button type="button" class="gc-secondary gc-craft-max" title="Craft ${max} at once" data-action="craftMax" data-id="${esc(r.id)}">×${max}</button>`:''}</div></div></article>`;
  }
  inventoryTab(db,actor){const mats=db.materials.filter(m=>this.group==='all'||(this.group==='metallurgy'?m.group!=='Alchemical Ingredient':m.group==='Alchemical Ingredient')).filter(m=>this.showZero||count(actor,m.id)>0).filter(m=>!this.search||m.name.toLowerCase().includes(this.search.toLowerCase()));
    const owned=db.materials.reduce((n,m)=>n+count(actor,m.id),0);
    const potions=actor.items.filter(i=>!!i.getFlag(ID,'recipeId')&&db.recipes.some(r=>r.id===i.getFlag(ID,'recipeId')&&r.category==='alchemy'));
    const equipped=actor.items.filter(i=>!!i.getFlag(ID,'recipeId')&&['weapon','equipment'].includes(i.type));
    return this.heading('fa-box-open','Character Inventory','Materials live on your D&D 5e sheet, not in a hidden module database.')+
      `<div class="gc-stats"><div>${icon('fa-boxes-stacked')}<b>${owned}</b><small>Units</small></div><div>${icon('fa-gem')}<b>${db.materials.filter(m=>count(actor,m.id)>0).length}</b><small>Materials owned</small></div><div>${icon('fa-flask')}<b>${potions.reduce((n,i)=>n+quantity(i),0)}</b><small>Potions owned</small></div></div>`+
      this.filterBar(materialGroups,this.group,'group')+`<button type="button" class="gc-secondary gc-toggle" data-action="toggleZero">${icon(this.showZero?'fa-eye-slash':'fa-eye')} ${this.showZero?'Owned only':'Show all materials'}</button>`+this.searchBar()+
      `<div class="gc-material-grid">${mats.map(m=>`<div class="gc-material ${count(actor,m.id)?'':'is-zero'}"><span class="gc-inv-icon" style="--gc-mat:${hue(m.color)}"><img src="${esc(m.img)}" alt=""></span><div class="gc-inv-name"><b>${esc(m.name)}</b><small>${esc(m.group)} · Tier ${num(m.tier,1)}</small></div><strong>×${count(actor,m.id)}</strong></div>`).join('')}</div>`+
      `<h3 class="gc-inv-title">${icon('fa-flask')} Ready-to-use Potions</h3><div class="gc-potion-list">${potions.map(i=>`<div class="gc-potion"><img class="gc-potion-icon" src="${esc(i.img)}" alt=""><div><strong>${esc(i.name)} ×${quantity(i)}</strong><small>${esc(db.recipes.find(r=>r.id===i.getFlag(ID,'recipeId'))?.description||'')}</small></div><button class="gc-secondary" data-action="drink" data-id="${esc(i.id)}" type="button">${icon('fa-flask-vial')} Use</button></div>`).join('')||'<p class="gc-help">Craft a potion to use it here. Non-healing effects are sent to chat for GM adjudication.</p>'}</div><h3 class="gc-inv-title">${icon('fa-shield-halved')} Crafted Equipment</h3><div class="gc-potion-list">${equipped.map(i=>`<div class="gc-potion"><img class="gc-potion-icon" src="${esc(i.img)}" alt=""><div><strong>${esc(i.name)}</strong><small>${esc(i.type==='weapon'?'Attack-ready weapon':'Equipable armor / shield')}</small></div><button class="gc-secondary" data-action="sheetItem" data-id="${esc(i.id)}" type="button">${icon('fa-up-right-from-square')} Item Sheet</button></div>`).join('')||'<p class="gc-help">Craft a weapon or shield to see it here.</p>'}</div>`;
  }
  gmTab(db){const kind=this.editor?.kind||'material',key=({material:'materials',node:'nodes',recipe:'recipes'})[kind],entries=db[key];
    return this.heading('fa-gears','GM Studio','Manage the catalogue, map deposits and three world compendiums with real D&D Items.')+
    `<div class="gc-gm-layout"><aside class="gc-gm-side"><div class="gc-gm-title">${icon('fa-sliders')} Library</div>
      ${[['material','Materials','fa-gem',db.materials.length],['node','Gathering Nodes','fa-mountain',db.nodes.length],['recipe','Recipes','fa-scroll',db.recipes.length]].map(([k,name,ic,len])=>`<button class="gc-gm-group ${kind===k?'is-on':''}" type="button" data-action="gmkind" data-id="${k}">${icon(ic)} ${name}<span>${len}</span></button>`).join('')}
      <div class="gc-gm-limit"><label>Gather attempts per character</label><div class="gc-inline"><input type="number" min="1" max="100" name="dailyLimit" value="${num(db.settings.dailyLimit,6,1,100)}"><button type="button" data-action="saveSettings" title="Save">${icon('fa-floppy-disk')}</button></div></div>
      <label class="gc-checkbox"><input type="checkbox" name="sceneOnly" ${db.settings.sceneOnly?'checked':''}> Scene-only gathering (15 ft from bound tokens)</label>
      <button type="button" class="gc-secondary gc-full" data-action="resetAttempts">${icon('fa-rotate-right')} Reset selected character</button>
      <button type="button" class="gc-secondary gc-full" data-action="sync">${icon('fa-book')} Create / Sync Compendiums</button>
      <p class="gc-help">World packs: <b>Ores & Metals</b>, <b>Alchemy Ingredients</b>, and <b>Ready-to-use Items</b>. Sync adds missing items only; edited copies are never overwritten. Drag these items onto actors, chest actors or scene loot inventories.</p></aside>
      <section class="gc-gm-main"><div class="gc-library"><div class="gc-lib-header"><strong>${kind==='material'?'Materials':kind==='node'?'Gathering Nodes':'Recipes'}</strong><button type="button" data-action="new">${icon('fa-plus')} New</button></div><div class="gc-lib-list">${entries.map(x=>`<button class="gc-library-item ${this.editor?.id===x.id?'is-active':''}" type="button" data-action="edit" data-id="${esc(x.id)}">${icon(x.icon)} <span>${esc(x.name)}</span>${icon('fa-chevron-right')}</button>`).join('')}</div></div>
      ${this.editor?.id?this.editorForm(db,kind,entries.find(x=>x.id===this.editor.id)):this.editor?.isNew?this.editorForm(db,kind,{}):'<div class="gc-empty gc-placeholder">Select an entry to edit or press New.</div>'}</section></div>`;
  }
  field(k,label,val,type='text',rest=''){return `<label class="gc-field"><span>${esc(label)}</span><input name="${k}" type="${type}" value="${esc(val??'')}" ${rest}></label>`;}
  select(k,label,options,chosen){return `<label class="gc-field"><span>${esc(label)}</span><select name="${k}">${options.map(([id,name])=>`<option value="${esc(id)}" ${id===chosen?'selected':''}>${esc(name)}</option>`).join('')}</select></label>`;}
  ingRow(ing,mats){return `<div class="gc-ing-row"><select name="ing-id">${mats.map(([id,name])=>`<option value="${esc(id)}" ${id===ing.id?'selected':''}>${esc(name)}</option>`).join('')}</select><input name="ing-qty" type="number" min="1" max="99" value="${num(ing.qty,1,1,99)}"><button type="button" data-action="removeIngredient" title="Remove ingredient">${icon('fa-xmark')}</button></div>`;}
  editorForm(db,kind,entry={}){const isNew=!entry.id,mats=db.materials.map(m=>[m.id,m.name]),groupChoices=[['Ore & Mineral','Ore & Mineral'],['Refined Metal','Refined Metal'],['Alchemical Ingredient','Alchemical Ingredient']];
    let extra='';
    if(kind==='material')extra=this.select('group','Resource group',groupChoices,entry.group||'Ore & Mineral')+this.field('tier','Tier',entry.tier||1,'number','min="1" max="4"')+this.field('color','Accent color',hue(entry.color),'color')+this.field('img','Image path',entry.img||'icons/svg/item-bag.svg');
    if(kind==='node')extra=this.select('materialId','Harvested material',mats,entry.materialId||mats[0]?.[0])+this.select('bonusId','Bonus find',[['','None'],...mats],entry.bonusId||'')+this.field('bonusChance','Bonus chance (%)',entry.bonusChance||0,'number','min="0" max="100"')+this.select('skill','Skill check',skills,entry.skill||'sur')+this.field('dc','DC',entry.dc||12,'number','min="1" max="40"')+this.field('minYield','Min yield',entry.minYield||1,'number','min="1" max="20"')+this.field('maxYield','Max yield',entry.maxYield||2,'number','min="1" max="20"')+`<label class="gc-checkbox"><input type="checkbox" name="active" ${entry.active!==false?'checked':''}> Available to players</label>`+(entry.id?`<button type="button" class="gc-secondary gc-full" data-action="bindToken">${icon('fa-map-pin')} Bind selected map token</button><p class="gc-help">Select a token on the scene as GM, then bind it to this node. Players can harvest within 15 ft when scene-only mode is on.</p>`:'');
    if(kind==='recipe'){
      const choices=[['','Use generated native Item'],...(game.items?.contents||[]).filter(i=>['loot','weapon','equipment','consumable','tool'].includes(i.type)).map(i=>[i.uuid,i.name])];
      extra=this.select('category','Profession',[['metallurgy','Metallurgy'],['alchemy','Alchemy']],entry.category||'metallurgy')+this.field('subcategory','Craft group',entry.subcategory||'Custom')+this.field('tier','Tier',entry.tier||1,'number','min="1" max="4"')+this.select('outputItemUuid','Linked World Item (optional)',choices,entry.outputItemUuid||'')+this.field('outputQuantity','Output count',entry.outputQuantity||1,'number','min="1" max="99"')+this.field('dc','Inspired craft DC',entry.dc||12,'number','min="1" max="40"')+this.field('effect','Potion effect note / healing:XdY+Z',entry.effect||'')+this.field('img','Item image path',entry.img||'icons/svg/item-bag.svg')+`<div class="gc-ingredients-editor"><div class="gc-ingredient-title">Ingredients<button type="button" data-action="addIngredient">${icon('fa-plus')} Add</button></div><div class="gc-ingredient-rows">${(entry.ingredients||[{id:mats[0]?.[0],qty:1}]).map(i=>this.ingRow(i,mats)).join('')}</div></div><p class="gc-help">Built-in daggers, swords, shields, and potions are ready to use. Custom recipes can link to any prepared World Item for full D&D5e actions.</p>`;
    }
    return `<form class="gc-gm-form" data-editor-form="1"><h3>${isNew?'New':'Edit'} ${esc(kind)}</h3><div class="gc-fields">${this.field('name','Name',entry.name||'')}${this.field('description','Description',entry.description||'')}${this.field('icon','Font Awesome icon',entry.icon||'fa-gem')}${extra}</div><div class="gc-form-actions"><button class="gc-primary" type="submit">${icon('fa-floppy-disk')} Save</button>${isNew?'':`<button class="gc-danger" type="button" data-action="delete" data-id="${esc(entry.id)}">${icon('fa-trash')} Delete</button>`}<button class="gc-secondary" type="button" data-action="cancel">Cancel</button></div></form>`;
  }
  async click(e){const button=e.target.closest('button[data-action]');if(!button||this.busy)return;const a=button.dataset.action,id=button.dataset.id;
    if(a==='tab'){this.tab=id;this.search='';this.group='all';this.page=1;return this.refresh();}
    if(a==='more'){this.page++;return this.refresh();}
    if(a==='readyOnly'){this.readyOnly=!this.readyOnly;this.page=1;return this.refresh();}
    if(a==='toggleZero'){this.showZero=!this.showZero;return this.refresh();}
    if(a==='gmode'){this.gatherMode=button.dataset.mode;return this.refresh();}
    if(a==='cmode'){this.craftMode=button.dataset.mode;return this.refresh();}
    if(a==='category'){this.category=id;this.page=1;return this.refresh();}
    if(a==='group'){this.group=id;this.page=1;return this.refresh();}
    if(a==='gather')return this.locked(()=>this.gather(id));
    if(a==='craft')return this.locked(()=>this.craft(id));
    if(a==='craftMax')return this.locked(()=>this.craft(id,10));
    if(a==='drink')return this.locked(()=>this.drink(id));
    if(a==='sheetItem'){const item=this.actor?.items?.get?.(id)||this.actor?.items?.find(i=>i.id===id);return item?.sheet?.render(true);}
    if(!game.user.isGM)return;
    if(a==='gmkind'){this.editor={kind:id,id:null};return this.refresh();}
    if(a==='new'){this.editor={kind:this.editor.kind,id:null,isNew:true};return this.refresh();}
    if(a==='edit'){this.editor={kind:this.editor.kind,id};return this.refresh();}
    if(a==='cancel'){this.editor={kind:this.editor.kind,id:null};return this.refresh();}
    if(a==='addIngredient'){const rows=this.element.querySelector('.gc-ingredient-rows'),mats=database().materials.map(m=>[m.id,m.name]);if(rows&&mats.length)rows.insertAdjacentHTML('beforeend',this.ingRow({id:mats[0][0],qty:1},mats));return;}
    if(a==='removeIngredient'){if(this.element.querySelectorAll('.gc-ing-row').length>1)button.closest('.gc-ing-row')?.remove();return;}
    if(a==='saveSettings')return this.locked(()=>this.saveSettings());
    if(a==='resetAttempts')return this.locked(()=>this.resetAttempts());
    if(a==='bindToken')return this.locked(()=>this.bindToken());
    if(a==='sync')return this.locked(()=>syncCompendiums());
    if(a==='delete')return this.locked(()=>this.deleteEntry(id));
  }
  change(e){if(e.target.name==='actor'){this.actorId=e.target.value;return this.refresh();}
    if(e.target.name==='sceneOnly'&&game.user.isGM)return this.locked(async()=>{const db=clone(database());db.settings.sceneOnly=e.target.checked;await game.settings.set(ID,'database',db);});
  }
  input(e){if(!e.target.matches('[data-search]'))return;this.search=e.target.value;this.page=1;clearTimeout(this.searchTimer);
    this.searchTimer=setTimeout(async()=>{await this.refresh();const field=this.element?.querySelector('[data-search]');if(field){field.focus();field.setSelectionRange?.(field.value.length,field.value.length);}},230);
  }
  submit(e){if(!e.target.matches('[data-editor-form]'))return;e.preventDefault();if(game.user.isGM&&!this.busy)return this.locked(()=>this.saveEntry(e.target));}
  async locked(fn){if(this.busy)return;this.busy=true;try{await fn();}catch(err){console.error(`${ID} | Action failed`,err);notify(err.message||'Unexpected error',true);}finally{this.busy=false;await this.refresh();}}
  checkActor(){const actor=this.actor;if(!actor||!(game.user.isGM||actor.isOwner))throw new Error('You do not own this character.');return actor;}
  async gather(id){const actor=this.checkActor(),db=database(),node=db.nodes.find(n=>n.id===id&&n.active);
    if(!node)throw new Error('That gathering node is unavailable.');
    if(db.settings.sceneOnly){const near=nearestNodeToken(actor,id);if(!near||near.feet>15)throw new Error('Move your character within 15 ft of the mapped gathering token.');}
    const mat=material(db,node.materialId);if(!mat)throw new Error('The resource no longer exists.');
    const cap=num(db.settings.dailyLimit,6,1,100),used=attempts(actor);if(used>=cap)throw new Error('No gathers left. The GM can reset your attempts.');
    const risky=this.gatherMode==='bold',dc=num(node.dc,12)+(risky?3:-2),roll=await new Roll('1d20 + @bonus',{bonus:skillBonus(actor,node.skill)}).evaluate();
    await actor.setFlag(ID,'attempts',used+1);const success=roll.total>=dc;let obtained=0,bonusText='';
    if(success){const minimum=num(node.minYield,1,1,20),maximum=Math.max(minimum,num(node.maxYield,2,1,20));obtained=(minimum+Math.floor(Math.random()*(maximum-minimum+1)))*(risky?2:1);await grantMaterial(actor,mat,obtained);
      const rare=material(db,node.bonusId);if(rare&&Math.random()*100<num(node.bonusChance,0,0,100)){await grantMaterial(actor,rare,1);bonusText=`<p>Rare find: <strong>${esc(rare.name)} ×1</strong></p>`;}
    }
    await announce(actor,`<p><b>${esc(actor.name)}</b> ${success?'harvested':'failed to harvest'} <b>${esc(node.name)}</b>.</p><p>${esc(skillLabels[node.skill]||node.skill)} ${roll.total} vs DC ${dc} (${risky?'Risky':'Careful'}).</p>${success?`<p>${esc(mat.name)} ×${obtained}</p>${bonusText}`:'<p>No materials gained. One attempt spent.</p>'}`);
    notify(success?`Harvested ${mat.name} ×${obtained}.`:'Gathering failed.');
  }
  async craft(id,maxBatch=1){const actor=this.checkActor(),db=database(),recipe=db.recipes.find(r=>r.id===id);if(!recipe)throw new Error('Recipe not found.');
    const inspired=this.craftMode==='inspired',required=requirements(actor,recipe,db,inspired);
    if(!required.length||required.some(i=>!i.mat||i.have<i.qty))throw new Error('Missing required materials.');
    if(recipe.outputItemUuid){const source=await fromUuid(recipe.outputItemUuid);if(!source||source.documentName!=='Item')throw new Error('Linked Item not found. GM must relink it.');}
    let twice=false,roll=null;
    if(inspired){roll=await new Roll('1d20 + @bonus',{bonus:skillBonus(actor,recipe.category==='alchemy'?'inv':'ath')}).evaluate();twice=roll.total>=num(recipe.dc,12);}
    const batch=maxBatch>1&&!inspired?Math.max(1,Math.min(10,...required.map(i=>Math.floor(i.have/i.qty)))):1;
    const consumed=required.map(i=>({id:i.id,qty:i.qty*batch})),amount=num(recipe.outputQuantity,1,1,99)*(twice?2:1)*batch;let paid=false;
    try{await consume(actor,consumed);paid=true;await grantProduct(actor,recipe,amount);}
    catch(e){if(paid){try{await refund(actor,consumed,db);}catch(err){notify('Item creation failed and refund failed. Contact the GM.',true);console.error(err);}}throw e;}
    await announce(actor,`<p><strong>${esc(actor.name)}</strong> crafted <strong>${esc(recipe.name)} ×${amount}</strong>.</p><p>${inspired?`Inspired craft ${roll.total} / DC ${num(recipe.dc,12)}${twice?' — bonus ×2':' — normal output'}`:`Reliable craft ×${batch} — success guaranteed.`}</p>`);
    notify(`Crafted ${recipe.name} ×${amount}.`);
  }
  async drink(itemId){const actor=this.checkActor(),item=actor.items.get?.(itemId)||actor.items.find(i=>i.id===itemId);
    if(!item||quantity(item)<1)throw new Error('Potion is no longer in this inventory.');
    const recipe=database().recipes.find(r=>r.id===item.getFlag(ID,'recipeId')&&r.category==='alchemy');
    if(!recipe)throw new Error('This is not a Gathering & Crafting potion.');
    const effect=String(item.getFlag(ID,'effect')||recipe.effect||'');
    const formula=/^healing:(\d+d\d+\+\d+)$/.exec(effect),tempFormula=/^temp:(\d+d\d+)$/.exec(effect);
    let roll=null,hpOld=null,healed=0,tempOld=null,tempGained=0;
    if(formula){roll=await new Roll(formula[1]).evaluate();const hp=actor.system?.attributes?.hp||{};if(!Number.isFinite(Number(hp.value))||!Number.isFinite(Number(hp.max)))throw new Error('Cannot find character HP.');
      hpOld=Number(hp.value);healed=Math.max(0,Math.min(Number(hp.max)-hpOld,Number(roll.total)));}
    if(tempFormula){roll=await new Roll(tempFormula[1]).evaluate();const hp=actor.system?.attributes?.hp||{};
      tempOld=Number(hp.temp||0);tempGained=Math.max(0,Number(roll.total)-tempOld);}
    // Consumption and HP update must succeed together. Restore the stack on error.
    const saved=item.toObject();try{
      if(quantity(item)===1)await actor.deleteEmbeddedDocuments('Item',[item.id]);else await item.update({'system.quantity':quantity(item)-1});
      if(formula&&healed>0)await actor.update({'system.attributes.hp.value':hpOld+healed});
      if(tempFormula&&tempGained>0)await actor.update({'system.attributes.hp.temp':tempOld+tempGained});
    }catch(error){try{if(formula&&hpOld!=null)await actor.update({'system.attributes.hp.value':hpOld});if(tempFormula&&tempOld!=null)await actor.update({'system.attributes.hp.temp':tempOld});}catch(e){console.error(`${ID} | HP rollback failed`,e);}try{const current=actor.items.get?.(itemId)||actor.items.find(i=>i.id===itemId);if(current)await current.update({'system.quantity':saved.system.quantity});else{delete saved._id;await actor.createEmbeddedDocuments('Item',[saved]);}}catch(e){console.error(`${ID} | potion rollback failed`,e);}throw error;}
    await announce(actor,`<p><b>${esc(actor.name)}</b> drinks <b>${esc(recipe.name)}</b>.</p><p>${esc(recipe.description)}</p>${formula?`<p>Healing roll: ${roll.total}; HP restored: <b>${healed}</b>.</p>`:tempFormula?`<p>Temporary HP roll: ${roll.total}; new temporary HP: <b>${tempOld+tempGained}</b>.</p>`:'<p><em>Apply the effect according to the item description; the GM adjudicates conditions and durations.</em></p>'}`);
    notify(`Used ${recipe.name}${formula?` (+${healed} HP)`:tempFormula?` (+${tempGained} temporary HP)`:''}.`);
  }
  async saveSettings(){const db=clone(database());db.settings.dailyLimit=num(this.element.querySelector('[name=dailyLimit]')?.value,6,1,100);db.settings.sceneOnly=!!this.element.querySelector('[name=sceneOnly]')?.checked;await game.settings.set(ID,'database',db);notify('Gathering settings saved.');}
  async resetAttempts(){const actor=this.checkActor();await actor.setFlag(ID,'attempts',0);notify(`Gather attempts reset for ${actor.name}.`);}
  async bindToken(){const nodeId=this.editor?.id;const token=canvas?.tokens?.controlled?.[0];if(!token||!nodeId)throw new Error('Select a scene token before binding a gathering node.');await token.document.setFlag(ID,'nodeId',nodeId);notify(`Selected token bound to ${database().nodes.find(n=>n.id===nodeId)?.name||nodeId}.`);}
  async deleteEntry(id){const kind=this.editor?.kind,key=({material:'materials',node:'nodes',recipe:'recipes'})[kind],db=clone(database()),entry=db[key]?.find(v=>v.id===id);if(!entry)return;
    if(kind==='material'&&(db.nodes.some(n=>n.materialId===id||n.bonusId===id)||db.recipes.some(r=>r.ingredients.some(i=>i.id===id))))throw new Error('This material is used by a node or recipe. Remove those dependencies first.');
    if(!await foundry.applications.api.DialogV2.confirm({window:{title:'Delete entry?'},content:`<p>Delete <strong>${esc(entry.name)}</strong> from the world catalogue? Items already owned by characters are unaffected.</p>`}))return;
    db[key]=db[key].filter(v=>v.id!==id);await game.settings.set(ID,'database',db);this.editor={kind,id:null};notify('Entry deleted.');
  }
  async saveEntry(form){if(!game.user.isGM)return;const db=clone(database()),kind=this.editor.kind,key=({material:'materials',node:'nodes',recipe:'recipes'})[kind],fd=new FormData(form);
    const name=String(fd.get('name')||'').trim().slice(0,90);if(!name)throw new Error('Enter a name.');
    const entry={id:this.editor.id||foundry.utils.randomID(12),name,description:String(fd.get('description')||'').trim().slice(0,350),icon:/^fa-[a-z0-9-]+$/.test(String(fd.get('icon')))?String(fd.get('icon')):'fa-gem'};
    if(kind==='material'){entry.group=['Ore & Mineral','Refined Metal','Alchemical Ingredient'].includes(fd.get('group'))?fd.get('group'):'Ore & Mineral';entry.tier=num(fd.get('tier'),1,1,4);entry.color=hue(fd.get('color'));entry.img=String(fd.get('img')||'icons/svg/item-bag.svg').slice(0,250);}
    if(kind==='node'){entry.materialId=String(fd.get('materialId')||'');entry.bonusId=String(fd.get('bonusId')||'');entry.bonusChance=num(fd.get('bonusChance'),0,0,100);entry.skill=skillLabels[fd.get('skill')]?String(fd.get('skill')):'sur';entry.dc=num(fd.get('dc'),12,1,40);entry.minYield=num(fd.get('minYield'),1,1,20);entry.maxYield=Math.max(entry.minYield,num(fd.get('maxYield'),2,1,20));entry.active=fd.get('active')==='on';entry.group=material(db,entry.materialId)?.group==='Alchemical Ingredient'?'alchemy':'metallurgy';if(!material(db,entry.materialId))throw new Error('Choose a valid material.');}
    if(kind==='recipe'){
      entry.category=fd.get('category')==='alchemy'?'alchemy':'metallurgy';entry.subcategory=String(fd.get('subcategory')||'Custom').slice(0,40);entry.tier=num(fd.get('tier'),1,1,4);entry.outputItemUuid=String(fd.get('outputItemUuid')||'');entry.outputQuantity=num(fd.get('outputQuantity'),1,1,99);entry.dc=num(fd.get('dc'),12,1,40);entry.effect=String(fd.get('effect')||'').slice(0,100);entry.img=String(fd.get('img')||'icons/svg/item-bag.svg').slice(0,250);
      const merged=new Map(),ids=fd.getAll('ing-id').map(String),counts=fd.getAll('ing-qty');ids.forEach((i,idx)=>merged.set(i,(merged.get(i)||0)+num(counts[idx],1,1,99)));
      entry.ingredients=[...merged].map(([id,qty])=>({id,qty}));if(!entry.ingredients.length||entry.ingredients.some(i=>!material(db,i.id)))throw new Error('Choose at least one valid ingredient.');
      if(entry.outputItemUuid){const it=await fromUuid(entry.outputItemUuid);if(!it||it.documentName!=='Item')throw new Error('Linked Item not found.');}
    }
    const ix=db[key].findIndex(v=>v.id===entry.id);if(ix>=0)db[key][ix]=entry;else db[key].push(entry);
    await game.settings.set(ID,'database',db);this.editor={kind,id:entry.id};notify('Saved to world catalogue. Use Sync Compendiums to add missing Items.');
  }
}
let windowInstance;
function open(actor){if(!windowInstance)windowInstance=new GatheringCrafting();if(actor&&(game.user.isGM||actor.isOwner))windowInstance.actorId=actor.id;windowInstance.render({force:true});return windowInstance;}
function launcher(html,selector,actor){const root=html instanceof HTMLElement?html:html?.[0],parent=root?.querySelector(selector);if(!parent||parent.querySelector('.gc-launcher'))return;
  const button=document.createElement('button');button.type='button';button.className='gc-launcher';button.title='Gathering & Crafting';button.innerHTML=`${icon('fa-hammer')} <span>Gathering & Crafting</span>`;button.addEventListener('click',e=>{e.preventDefault();open(actor);});parent.append(button);
}
Hooks.once('init',()=>{
  if(game.system.id!=='dnd5e')return;
  game.settings.register(ID,'database',{name:'Gathering & Crafting Catalogue',scope:'world',config:false,type:Object,default:clone(CATALOG),onChange:()=>{if(windowInstance?.rendered)windowInstance.render();}});
  game.settings.register(ID,'backup010',{name:'Legacy Catalogue Backup (v0.1.0)',scope:'world',config:false,type:Object,default:{}});
  game.settings.register(ID,'compendiumBootstrapped',{name:'Legacy compendiums created',scope:'world',config:false,type:Boolean,default:false});
  game.settings.register(ID,'compendiumBootstrapped030',{name:'v0.3 native item compendiums created',scope:'world',config:false,type:Boolean,default:false});
  game.settings.register(ID,'backup020',{name:'Catalogue backup before v0.3.0',scope:'world',config:false,type:Object,default:{}});
  game.keybindings.register(ID,'open',{name:'Open Gathering & Crafting',hint:'Open gathering and crafting for your selected character.',editable:[{key:'KeyG',modifiers:['ALT']}],onDown:()=>{open();return true;},restricted:false,precedence:CONST.KEYBINDING_PRECEDENCE.NORMAL});
});
Hooks.once('ready',async()=>{
  if(game.system.id!=='dnd5e'){if(game.user.isGM)notify('Gathering & Crafting requires the dnd5e system.',true);return;}
  const mod=game.modules.get(ID);if(mod)mod.api={open,getDatabase:()=>clone(database()),syncCompendiums,version:VERSION};
  if(!game.user.isGM)return;
  try{
    let old=database();if(!validDb(old)||num(old.catalogVersion,0)<2){
      if(validDb(old))await game.settings.set(ID,'backup010',clone(old));
      old=mergeCatalog(old);await game.settings.set(ID,'database',old);
    }
    if(num(old.catalogVersion,0)<3){
      await game.settings.set(ID,'backup020',clone(old));
      const upgraded=clone(old);const known=new Map([...CATALOG.materials,...CATALOG.recipes].map(i=>[i.id,i]));
      // Upgrade only bundled v2 icon paths; leave GM-authored paths and custom item edits alone.
      for(const entry of [...upgraded.materials,...upgraded.recipes]){
        const art=known.get(entry.id)?.img;
        if(art?.includes('/icons/painted/')&&String(entry.img||'').includes('/icons/v2/'))entry.img=art;
      }
      upgraded.catalogVersion=3;
      await game.settings.set(ID,'database',upgraded);
      notify('Catalogue upgraded. Previous recipes and customized Items were preserved.');
    }
    if(!game.settings.get(ID,'compendiumBootstrapped030'))await syncCompendiums();
  }catch(e){console.error(`${ID} | Setup failed`,e);notify('Compendium setup needs GM attention. Open GM Studio and select Create / Sync Compendiums.',true);}
});
for(const hook of ['renderActorDirectory','renderActorDirectoryV2'])Hooks.on(hook,(app,html)=>launcher(html,'.directory-header, header.directory-header, .header-actions',null));
for(const hook of ['renderActorSheet','renderActorSheetV2'])Hooks.on(hook,(sheet,html)=>{const actor=sheet.actor||sheet.document;if(actor&&['character','npc'].includes(actor.type)&&(game.user.isGM||actor.isOwner))launcher(html,'.sheet-header, .window-header .window-controls',actor);});
